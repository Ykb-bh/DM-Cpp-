#include <iostream>
#include <vector>
#include <list>
#include <map>
#include <set>

class IGraph
{
public :
  virtual int nbNodes() const = 0 ;
  virtual int nbEdges() const = 0 ;
  virtual int degree(int i) = 0 ;
  virtual std::vector<int> adjacency(int i) = 0;
  virtual void addEdges(int i , int j) = 0 ;
  virtual void addNode(int i) = 0 ;
  virtual void display_graph_adjacency() = 0 ;

  /*std::ostream& operator <<(std::ostream& out, const IGraph &g){
    out << g.display_graph_adjacency() ;
    //out << *g.nbNodes() ;
    return out ;
  }*/
  
};

class Graph : public IGraph
{
public :
  Graph(int N)
    : nbNodes_(N)
  {}
  int nbNodes() const {
    return nbNodes_ ;
  }
  int nbEdges() const {
    return nbEdges_ ;
  }
  int degree(int i) {
    return graph_[i].size();
  }
  void addEdges (int i, const int j){    
    if (graph_[j].find(i) != graph_[j].end() )
      nbEdges_++ ;
    graph_[i].insert(j) ;
    graph_[j].insert(i) ;
  }
  void addNode(int i) {
    graph_[i] = {};
    nbNodes_++;
  }
  std::vector<int> adjacency(int i) {
    std::vector<int> tmp ;
    auto it = graph_[i].begin() ;
    for(it; it != graph_[i].end() ; ++it)
      tmp.push_back(*it);
    return tmp ;
  }
  void display_graph_adjacency() {
    std::cout<< "test"<<std::endl;
    for(int i = 0; i<nbNodes_; ++i){
      std::cout << "sommet  " << i <<" : ";
      auto it = graph_[i].begin() ;
      for(it; it != graph_[i].end() ; ++it)
	std::cout << *it << " " ;
      std::cout << std::endl ;
    }
  }

  
private:
  int nbNodes_ ;
  int nbEdges_ ;
  std::map<int , std::set<int>> graph_ ;
};


class IGraphColoring
{
  std::vector<int > coloring(const IGraph& G) = 0 ;
};

class gloutonne : public IGraphColoring{

public :
  gloutonne(int nbcolors)
   
  {
    nbcolors_ = nbcolors ;
    for(int i = 0; i<nbcolors; ++i)
      colors.push_back(i) ;
  }
  std::vector<int> coloring(const IGraph& G){
    int nb = G.nbNodes();
    std::vector<int> tmp ;
    tmp[0] = colors[0] ;
    for (int i = 1 ; i<nb; ++i)
      tmp[i] = -1 ;
    for (int j = 1 ; j<nb; ++j){
      auto adj = G.adjacency(j);
      for (int l = 0; l<adj.size(); ++l){
	std::set<int> t ;
	if (tmp[l] != -1){
	  t.insert(tmp[l]);
	}
	int min = 9999; // suffisament grand
	for (auto it = t.begin(); it != t.end(); ++it)
	  if (*it < min)
	    min = *it ;
      }
      tmp[j] = colors[min+1];
    }
      
  }
private :
  int nbcolors_ ;
  std::vector<int> colors ;
};

int main (){
  IGraph *g = new Graph(5) ;
  g->addEdges(0, 0);
  g->addEdges(0, 1);
  g->addEdges(0, 2);
  g->addEdges(0, 3);
  g->addEdges(1, 0);
  g->addEdges(2, 0);
  g->addEdges(2, 3);
  g->addEdges(2, 4);
  g->addEdges(3, 0);
  g->addEdges(3, 2);
  g->addEdges(4, 2);
  g->display_graph_adjacency() ;
  std::cout<< g->nbNodes() <<" "<<g->nbEdges() <<std::endl;
  //std::cout << g ;
  IGraphColoring *Glou = new gloutonne();
  auto = g->coloring(3);
  return 0 ;
}
