#include <iostream>
#include <cmath>
#include <array>
#include <random>
#include <vector>
#include <algorithm>
#include <memory>  // std::shared_ptr<int> p(new int);
#include "../matplotlibcpp.h"

namespace plt = matplotlibcpp ;


class Hypothese
{
public :
  Hypothese(){}
  virtual ~Hypothese(){}
  
  virtual int nbparametres() const = 0 ;
  virtual double eval(const double x) const = 0 ; 
  virtual double deriv(const double x, const int i ) const = 0 ;
  virtual double& theta(int i) = 0; //   
};

template<int N> 
class Polynome : public Hypothese
{
public : 
  Polynome() {}
  int nbparametres() const {
    return Theta.size();
  }
  double eval(const double x) const {
    double ret ;
    for (int i = 0; i<N; i++){
      ret += Theta[i]*std::pow(x , i);
    }
    return ret ;
  }

  double deriv(const double x, const int i) const {
    double ret = std::pow(x, i);
    return ret ;
  }
  double & theta(int i ) { return Theta[i] ; }

  /*friend std::ostream& operator << (std::ostream &out , Polynome &P){
    //for (int i = 0; P.nb_parameters() ; ++i)
    out << P.Theta[0] <<" " << P.Theta[1] ;
    return out ;
    }*/
  
private :
  std::array<double, N+1> Theta ;
  
};

// Optimiseur ---------------------------------------------------------------------------
class Optimiser
{
 public :
  virtual double & update(int i) = 0;
  virtual void reset () = 0 ;
  virtual void step () = 0 ;
  virtual double lr() = 0 ;
};
// Optimiseur niveau zéro : gradient Descent stochastique ---
class SGD : public Optimiser
{
public :
  SGD(Hypothese& m , double lrr)
    : model_ (&m)
    , update_ (m.nbparametres() , 0.)
    , lr_ (lrr) {}
  
  double& update(int i ) { return update_[i]; }
  
  void reset(){
    std::fill(update_.begin() , update_.end() , 0.);
  }
  void step (){
    for(auto i = 0 ; i < model_ -> nbparametres(); ++i)
      model_ -> theta(i) -= update_[i] ;
  }
  double lr(){
    return lr_ ;
  }
  
private :
  Hypothese* model_;
  std::vector<double> update_ ;
  double lr_ ;
};

// Loss function ----------------------------------------------------------------------
class Lossfunction{
public :
  virtual double eval  (const Hypothese& H, const std::vector<double>& x , const std::vector<double>& y ) const = 0 ;
  virtual void backward (const Hypothese& H , Optimiser& optim ,const std::vector< double>& x, const std::vector<double>& y) const = 0;

};
// Fonction de cout de type Erreur quadratique moyenne ---
class MeanSquarError : public Lossfunction
{
public :
  MeanSquarError (){} ;
  double eval (const Hypothese& H, const std::vector<double>& x , const std::vector<double>& y ) const
  {
    auto J = 0. ;
    auto m = x.size();
    for(int i = 0 ; i<m ; i++ )
    {
      auto h = H.eval(x[i]) - y[i] ;
      J += h * h ;
    }
    return J / (2. * m) ;
  }
  void backward (const Hypothese& H , Optimiser& optim ,const std::vector< double>& x, const std::vector<double>& y) const {
    for (auto j = 0; j < x.size() ; ++j){
      const auto h = H.eval(x[j]) - y[j] ;    
      for (auto i = 0 ; i < H.nbparametres() ; ++i)
	optim.update(i) += optim.lr() * h * H.deriv(x[j] , i);
    }
    //return 0.5 * h * h ;
  }
  
};

//Trainter ---------------------------------------------------------------------------------
class Trainer {
public :
  virtual std::vector<double> train(const std::vector<double> &x, const std::vector<double> &y) const = 0 ;
};
// Traineur Gradient descent ----------

class GradientDescent : public Trainer
{
public :
  GradientDescent(Hypothese& H, Optimiser& optim, Lossfunction& lossF, const int N)
    : H_(&H)
    , optim_(&optim)
    , loss_func_(&lossF)
    , N_iter(N){}

  std::vector<double> train(const std::vector<double> &x, const std::vector<double> &y) const {
    auto Erreur_ = std::vector<double>() ;
    for (auto iter = 0 ; iter < N_iter ; ++iter){
      optim_ -> reset();
      loss_func_ -> backward(*H_ , *optim_, x , y);
      optim_ -> step();
      auto J = loss_func_ -> eval(*H_ , x, y);
      Erreur_.push_back(J);
    }
    return Erreur_ ;
  }
private :
  Hypothese*      H_ ;
  Optimiser*    optim_ ;
  Lossfunction*  loss_func_;
  int N_iter ;
};

// Dataset ---------------------------------------------------------------------------------
auto  data_set(const int n){
  std::pair<std::vector<double>, std::vector<double>> ret ;
  std::random_device random_device;
  std::mt19937 random_engine(0);
  std::uniform_real_distribution<double> dist_mean(0.0 , 10.0);
  std::vector<double> x ;
  for (int i = 0; i<n; i++){
    double xx = dist_mean(random_engine);
    x.push_back(xx);
  }
  // On va prendre : f(x) = ax^2 + bx + c : Fonction de base 
  std::vector<double> y ;
  const int a = 4, b = 10, c = 1 ;
  //const int a = 0, b = 10, c = -1 ; // pour tester le cas de polynome de degré 1
  for (int i =0; i<n; i++){
    double yy = a * x[i]*x[i] + b * x[i] + c ;
    y.push_back(yy);
  }
  ret.first  = x;
  ret.second = y;
  return ret ;
}


int main(int argc, char* argv[]){
  // Nombre d'itération et learning rate doivent etre entré en ligne de commande
  if (argc < 2){
    printf("%s\n" , "Nombre d'itération et learning rate doivent etre entré en ligne de commande");
    return 0 ;
  }
  //int ar = atoi(argv[1]) ;
  const int n_iter = atoi(argv[1]) ; ;
  char* ptr;
  const double lr = strtod(argv[2] , &ptr);
  //printf("%lf\n" , lr);
  if (n_iter < 0){
    printf("%s\n" , "Entrer un nombre d'itération correcte");
    return 0;
  }
  //printf("%d\n" , n_iter);
  std::pair<std::vector<double> , std::vector<double>> test = data_set(20);
  std::vector<double> x = test.first  ;
  std::vector<double> y = test.second ;
  
  Hypothese* P2 = new Polynome<3>() ;
  //Hypothese* P3 = new Polynome<3>() ;

  Optimiser*    sgd = new SGD(*P2 , lr);
  Lossfunction* mse = new MeanSquarError();
  Trainer*       gd = new GradientDescent(*P2, *sgd, *mse , n_iter) ;
  auto Erreur = gd -> train(x , y);
  plt::plot(x , y, "ks");
  //plt::plot(x , Erreur, "y");

  auto size = x.size() ;
  auto Test = std::vector<double>(size) ;
  
  for (auto i = 0; i<x.size() ; ++i){
    Test[i] = P2->eval(x[i]);
    //printf("%f\n" , Test[i]);
  }
  
  plt::plot(x, Test, "ro");
  plt::show();
  return 0 ;  
}
