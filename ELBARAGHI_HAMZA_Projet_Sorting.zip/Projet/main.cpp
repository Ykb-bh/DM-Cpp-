#include <iostream>
#include <algorithm>
#include <random>
#include <vector>
#include <chrono>
#include <ctime>

//#define n  10
const int n = 100; // taille de tableau

// fonction rand sert à générer des nombre aléatoires pour remplir le tableau
inline int rand(int p, int q){
    int size = q - p + 1;
    return (p+rand()%size);
}
// remplissage du tableau : 
template <class T >
void remplir(T v, int n){
  // std::cout<<"\n remplission..."<<std::endl;
  for (int i=0; i<n ; i++)
    v[i]=rand()%100+1;
}
// fonction swap utile dans le tri rapide : quicksort, pour échanger deux éléments
template <class T >
inline void swap(T &a, T &b){
    T k = a;
    a=b;
    b=k;
}

// fonction comp_swap utile dans le tri à bulle en échange si A[i]<A[i+1]
template<class T>
inline void comp_swap(T &A, T &B){
  if (B<A) swap(A, B);
}
// espace sorting : contenant les fonctions de tri à bulle et celles de tri rapide :
namespace sorting {
  //------------ Tri à bulle ---------------
  template<class T>
  void  Trie_bulle(T a, int n){
    for (int i=0; i<n; i++)
      for (int j=0; j<n-i-1; j++)
	comp_swap(a[j],a[j+1]);
  }
  //----------------------------------------

  //-------------Tri rapise -----------------
  template <class T >
  int Partition(T a, int lo, int hi){
    int t = rand(lo, hi);
    swap(a[t], a[hi]);

    int index = lo - 1;
    int key = a[hi];
    for (int i = lo; i<hi; i++){
      if (a[i] <= key)
	swap(a[++index], a[i]);
    }
    swap(a[++index], a[hi]);
    return index;
  }

  template <class T >
  void quickhelp(T a, int lo, int hi){
    if (lo<hi){
      int index = Partition (a, lo, hi);
      quickhelp(a, lo, index-1);
      quickhelp(a, index+1, hi);
    }
  }

  template <class T >
  void quicksort(T a, int n){
    quickhelp(a, 0, n-1); 
  }
  //------------------------------------------------------
}


int main(){

  //Déclaration de tableau à trier comme vector :
  std::vector<int> v (n);
  // v.data() : en retourne le pointeur vers le premier élément du vector
  // pour pouvoir l'utiliser dans les fonctions de tries !
  
  int *a = v.data();
  remplir(a, n);   // initialiser remplir le tableau à trier par des valeurs aléatoires
  std::cout<<"----Initialisation----:"<<std::endl;
  for (int i=0; i<n; i++){
    std::cout<<v[i]<<" ";
  }
  std::cout<<"\n"<<std::endl;

  // J'ai utiliser steady_clock car il dépend directement des impulsion d'horloge et non pas à l'horloge murale
  // ---- Tri à bulle ----------------------------------------------------
  std::cout << "----TRi à bulle----:"<<std::endl;
  auto start = std::chrono::steady_clock::now();
  sorting::Trie_bulle(a, n);
  auto end   = std::chrono::steady_clock::now();
  auto diff  = end - start ;
  // Afficher le temps en nanoseconds !
  std::cout << std::chrono::duration<double, std::nano> (diff).count() << "ns" << std::endl;
  // Affichage des éléments du tableau trié : 
  for (int i=0; i<n; i++){
    std::cout<<a[i]<<" ";
  }
  std::cout <<"\n"<<std::endl;
  
  // ----- Tri rapide ----------------------------------------------------
  std::cout << "----TRi rapide----:"<<std::endl;
  start = std::chrono::steady_clock::now();
  sorting::quicksort(a, n);
  end   = std::chrono::steady_clock::now();
  diff  = end - start ;
  // Afficher le temps en nanoseconds !
  std::cout << std::chrono::duration<double, std::nano> (diff).count() << "ns" << std::endl;
  // Affichage des éléments du tableau trié : 
  for (int i=0; i<n; i++){
    std::cout<<a[i]<<" ";
  }
  std::cout <<"\n"<< std::endl;

   // ----------- Fconction sort prédéfine en C++ ---------------------------
  std::cout << "----sort prédéfinie----:"<<std::endl;
  start = std::chrono::steady_clock::now();
  std::sort(v.begin(), v.begin()+n);
  end   = std::chrono::steady_clock::now();
  diff  = end - start ;
  // Afficher le temps en nanoseconds !
  std::cout << std::chrono::duration<double, std::nano> (diff).count() << "ns" << std::endl;
  // Affichage des éléments du tableau trié : 
  for (int i=0; i<n; i++){
    std::cout<<a[i]<<" ";
  }
  std::cout <<"\n"<< std::endl;

  /* Comentaires :
  ** Le trie à bulle :
     Nous allons parcourir le tableau de gauche à droite, SI l'élément est plus grand que le suivant, on l'échange, jusqu'à ce que le tableau soit trié : après la première itération, la première élément, le plus grand élément sera à la findu tableau, après deux itérations, les deux plus grands éléments seront au bonendroit..., après pas plus de n itérations, le tableau sera trié, ainsi la complexité de l'algorithme est quadratique O(n²) au pire des cas, O(n) au meilleur cas : tableau trié 

  ** Le trie rapide :
  On choisie un élément pivot, après en regroupe tous les éléments les plus petits que celui-ci à gauche et les plus grand à droite, puis récursivement en applique le meme principe sur les deux parties, en obtient à la fin le tableau trié : comportement asymptotique O(nlog(n)) . 

  ** en comparaison avec sort prédéfénie dans la librairie standard de C++
  J'ai obtenu des résultats pas stables entre ces deux dérniers !
 */
}
