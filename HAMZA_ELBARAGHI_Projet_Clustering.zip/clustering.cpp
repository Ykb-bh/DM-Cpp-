#include <map>
#include <utility>
#include <vector>
#include <algorithm>
#include <iostream>
#include <math.h>
#include <set>
#include <float.h>
#include <cmath>
#include <string>
#include "../matplotlibcpp.h"
#include <random>

namespace plt = matplotlibcpp ;

std::random_device random_device;
std::mt19937 random_engine(35); // J'ai essayer plusieurs valeurs de seed, et j'ai gardé 35
                                // correspond au meilleur data set pour mon implémentation, 
std::vector<double> t1,t2;

// make_blob---------------------------------------------
auto make_blob (int nb_points, int nb_clusters){
  std::uniform_real_distribution<double> dist_means (0.0 , 10.0);
  std::pair< std::vector<double>, std::vector<double> > ret ; 
  std::vector<double> vx;
  std::vector<double> vy;
  for (int i =0; i<nb_clusters; ++i){
    double f1 = dist_means (random_engine) ;
    double f2 = dist_means (random_engine) ;
    vx.push_back(f1) ;
    vy.push_back(f2) ;
    for(int j=1; j<nb_points; ++j){
      std::normal_distribution<double> dist_x (f1, 0.5) ;
      std::normal_distribution<double> dist_y (f2, 0.5) ;
      double d1 = dist_x(random_engine) ;
      double d2 = dist_y(random_engine) ;
      vx.push_back(d1);    
      vy.push_back(d2);
    }
  }
  ret.first  = vx ;
  ret.second = vy ;
  // On récupére dans un pair deux tableaux de coordonnées des points générés par la loi normal, pour chaque centre.
  return ret ;
}

// K-means ---------------------------------------------

// Voir le corps de la fonction k-means pour la description de la fonction convergence!
// Principe : Convergence si les centres des clusters ne bougents plus :

bool convergence (int nb_clusters ,const std::vector<double> & u,const std::vector<double> & v ,const std::vector<double> & prev_u,const std::vector<double> & prev_v){
  int c = 0 ;
  for (int k = 0; k<nb_clusters; k++){
    if ( (abs(prev_u[k] - u[k]) == 0  ) && ( abs(prev_v[k] - v[k]) == 0 ) )
      c++;
  }
  if (c == nb_clusters)
    return true ;
  return false ;
}

// K-means algorithm -----------------------------------------------------

auto k_means(int nb_clusters, int nb_points, auto x, auto y){

  /* la fonction retourne une structure de données de type map<int, pair<vect,vect>> : 
     la clé : (int) contient le numéro de cluster, 
     la valeur associée est les coordonnées des points appartenants à ce cluster 
  */
  std::map<int , std::pair<std::vector<double>, std::vector<double>> > ret ;  
  
  // Définir les centres initials:
  // On définie les centres initials d'une manière aléatoire,
  // NB : Ce caractére alétoire des centres initials pose un problème fondamental dans la convergence de l'algorithme de clustring et dans le résultat lui meme de cet algorithme.
  // En effet : Si par exemple toutes les centres ou plusieurs centres choisis sont très proches, certains centres peuvent ne pas changés dans au fur et à mesure, du coup on peut avoir un regroupement qui n'est pas très bon ou moins significatif,
  // Pour régler ce problème on peut choisir le ppremière centre d'une manière aléatoire, et puis on cherche le centre prochain de telle façon à ce qu'il soit pas très proche au centres précédentes : C'est la version k-means++ .
  std::uniform_int_distribution<int> dist_means (0 , nb_points-1);
  std::vector<double> u,v ;
  std::vector<double> prev_u, prev_v;
  std::mt19937 random_engine2(7);
  for (int i = 0; i<nb_clusters; i++){    
    int c = dist_means(random_engine2) ;
    std::cout<<"indice :  "<< c <<std::endl;
    std::cout<< x[c] << "  " << y[c] <<std::endl;
    u.push_back(x[c]) ;
    v.push_back(y[c]) ;
    prev_u.push_back(0.0) ;
    prev_v.push_back(0.0) ;
  }
  // -------------------------------------------------
  std::vector<int> which_cluster ;
  for (int i = 0; i<nb_points; i++){
    which_cluster.push_back(1) ;
  }
  // Le tableau which_cluster sert à stocker les clusters correspondant à chaque point
  // par exemple : which_cluster = [2, 0, 3,...] veut dire que :
  // le premièr point à partient au cluster numéro 2, le deuxième au cluster numéro 0 et ainsi de suite.
  
  // ------------------------------------------------
  
  // On commence le regroupements des points, jusqu'à ce qu'on ait le clustring optimal des points
  // Chaque itération de la boucle while, on parcoure sur toutes les points, et on les regroupent selon les centres les plus proches, et on actualise les coordonnées des centres au fur et à mesure, 
  // On recommence (le regroupement) les itération sur toutes les points, jusqu'à convergence .

  while (convergence(nb_clusters, u, v , prev_u, prev_v) == false ) {
    /*
      std::cout<<"previous centres"<<std::endl;
      for (int i = 0; i<nb_clusters; ++i){
      std::cout<<"prev_u["<<i<<"] = "<<prev_u[i] <<"  prev_v["<<i<<"] = "<<prev_v[i] <<std::endl;
      
      std::cout<<"centres"<<std::endl;
      for (int i = 0; i<nb_clusters; ++i)
      std::cout<<"u["<<i<<"] = "<<u[i] <<"   v["<<i<<"] = "<<v[i] <<std::endl;
    */
    
    // Calculer les distance entre le point (x[i],y|i]) et toutes les centres
    // Le centre le plus proche représente le cluster actuel auquel le point est affecté
    for (int i = 0; i<nb_points; ++i){
      double dist_min = sqrt( (x[i]-u[0])*(x[i]-u[0]) + (y[i]-v[0])*(y[i]-v[0]));
      int index_min = 0  ;
      for (int j = 1; j < nb_clusters; ++j){
	double dist = sqrt( (x[i]-u[j])*(x[i]-u[j]) + (y[i]-v[j])*(y[i]-v[j]));
	if (dist <= dist_min){
	  dist_min  = dist ;
	  index_min = j    ;
	}
      }
      // std::cout<< "index_min = " <<index_min<< std::endl;
      // Affectation de clusters correspondant au point i :
      which_cluster[i] = index_min ;
            
      // Stocker les coordonnées des centres de l'itération actuelle
      for (int i = 0; i<nb_clusters; i++){
	prev_u[i] = u[i] ;
	prev_v[i] = v[i] ;
      }    
      // Actualiser les coordonnées des centres
      // en calculant la moyenne des des coordonnées de tous les points dans chaque clusters :
      for (int i = 0; i<nb_clusters; ++i){
	if (ret[i].first.empty() == false && ret[i].second.empty() == false ){
	  std::vector<double>::iterator it_x = ret[i].first.begin();
	  std::vector<double>::iterator it_y = ret[i].second.begin();
	  double mean_x = 0.0 ;
	  double mean_y = 0.0 ;
	  while( it_x != ret[i].first.end() && it_y != ret[i].second.end() ){
	    mean_x += *it_x;
	    mean_y += *it_y;
	    it_x++ ;
	    it_y++ ;
	  }
	  // n : le nombre de points existe dans le clusters numéro i
	  int n = std::count(which_cluster.begin(), which_cluster.end(), i) ;
	  u[i] = mean_x / n  ; //
	  v[i] = mean_y / n  ; //
	}
      }
      
    }

    
    // Après avoir affecter chaque point au cluster correspondant, et actualiser les centres
    // On insére les coordonnées des points dans la structure de donnée ret à retournée de type map
    // chaque element de ret contient le numéro de cluster (unique)
    // et les élements qui constituent se cluster : obtenu après avoir affecter les points au clusters correspondants
    // Lorsqu'on ajoute le point (xj,yj) au cluster i on vérifier bien que le point (xj,yj) n'appartient pas au autres clusters différents de j : Si ce point est trouvé dans un cluster autre que i on le supprime 
    for (int i = 0; i<nb_points; i++ ){
      int index = which_cluster[i] ;
      /*for (int j = 0; j<nb_clusters ; j++){
	auto it_x = std::find(ret[j].first.begin() , ret[j].first.end()  , x[i] ) ;
	auto it_y = std::find(ret[j].second.begin() , ret[j].second.end(), y[i] ) ;
	if (it_x != ret[j].first.end() && it_y != ret[j].second.end() ){
	  if ( std::distance(ret[j].first.begin() , it_x) == std::distance(ret[j].second.begin(), it_y) ){
	    ret[j].first.erase(it_x) ;
	    ret[j].second.erase(it_y);
	  }
	} 
	}*/
      ret[index].first.push_back(x[i]);
      ret[index].second.push_back(y[i]);      
    }
    // On recommence le meme traitement : On regroupe les points selon les centres après avoir actualisés...
    // jusqu'à ce que les centres ne bougent plus ou bougent très lentement : d'où la fonction de Convergence définie plus haut
    // Convergence atteinte => On sort de la boucle while on récupérent le clustring final des points !

    // on récupére les centres des clusters dans l'itération finale pour pouvoire les afficher séparément
    t1 = u ; 
    t2 = v ;    
  }
  
  // On retourne les éléments de chaque cluster regroupés dans une structure de type table associative (ou table de hashage)
  // dont la clé est le numéro de cluster et la valeur est les éléments associés à ce cluster,
  // J'ai choisi cette structure de donnée map, pour faciliter l'accées au élément de cluster au moment de l'affichage (Voir main)
  // ET surout surout, lors de l'affichage en coleur :
  // Il suffit d'adopter une technique de choisir un coleur pout chaque cluster (voir main) 
  return ret ;
}

int main() {

  /* Pour exemple : je génére 5 groupes de points par la fonction make_blob : chaque groupe contient 100 points, soit au total 500 points
     Puis j'appel le programme k-means avec k = 3 : le nombre de clusters .
     On affiche le data set avant et après le k-means
  **** NB : Pratiquement Le choix de k dans l'algorithm k-means a aussi un role important 
      (en plus de chois des centres initials dans la donction k-means)
      ****  Il se peut que l'algorithm k-means ne donne pas de résultats bien précis, meme si on donne le nombre de clusters
      égale au nombre de blob dans la fonction make_blob,
      ****  Pour résoudre ce problème, on implémente le k-means avec plusieurs valeurs de k 
      pour un data set donné, et des centres initials bien choisi, 
      et on maintient le k dont le clustring est bien répartie selon l'intérprétation des données qu'on traite .
      
  **** Pour mon implémentation, Meme si j'ai pas adopter l'algorithme k-means++ (dont le chois des centres initials n'est pas aléatoire)
      J'ai comme meme essayer manuellement plusieurs valeurs de k, pour une data set donnée : ici 100 points par blob générés par make_blob!
      et j'ai maintenu la valeur de k = 3, dont la répartition des clusters apparait plus raisonable,
 */
  
  std::map <int , std::pair<std::vector<double>, std::vector<double>>> test ;
  std::pair<std::vector<double>, std::vector<double>> blob ;
  
  const int nb_clusters = 3  ;
  const int nb_points   = 100; // nombre de points par blob !
  blob = make_blob(100, 5)   ;
  plt::plot(blob.first, blob.second, "go");
  plt::show();

  test = k_means(3, 500, blob.first, blob.second) ;
  
  plt::plot(t1, t2, "ks"); // Affichade des centres des clusters

  /*  Affichage des clusters avec k = 3, manuellement 
  plt::plot(test[0].first, test[0].second, "bo");
  plt::plot(test[1].first, test[1].second, "go");
  plt::plot(test[2].first, test[2].second, "ro");
  plt::show() ;
  */
  
  /* Afin de pouvoir afficher les clusters pour n'importe quel valeurs de k avec des coleurs différents :
     On peut affecter d'une manière aléatoire une coleur à un cluster donné,
     **** Il faut noter que dans le cas où k est grand (supérieurs au nombre de coleurs usuels supportés par matplotlibcpp):
     deux clusters peuvent etre de la meme coleurs alors qu'ils sont très proches
     Ce qui peut provoquer des confusions au niveaux de la visualisation !!! 
     C'est pour cela, j'ai adopter pour l'exemple l'affichage manuel de chaque cluster avec coleur différent
  */
  
  // Affichage des clusters en coleurs différents  :
  std::vector<std::string> color_str = {"bo", "go", "ro","ko", "yo", "co"};
  std::uniform_int_distribution<int> color(0, 5);
  for (int i = 0; i<nb_clusters; i++){
    int cc = color(random_engine) ;
    plt::plot(test[i].first, test[i].second, color_str[cc]);
  }
  plt::show();
  

    // Affichage des coordonnées des points, et le nombre d'éléments dans chaque clusters
  for (int i = 0; i<nb_clusters; i++){
    std::cout<< "test    : " << i << "----------------------------------------------------" <<std::endl;
    // Afficher le nombre de points dans chaque clusters :
    std::cout<< test[i].first.size() << "    " << test[i].second.size() <<std::endl; 
    auto x = test[i].first.begin()   ;
      auto y = test[i].second.begin()  ;
      while (x!=test[i].first.end() && y!=test[i].second.end() ){
      std::cout<< *x << "        " << *y <<std::endl;
      x++; y++;
      }
  }
  return 0;
}
